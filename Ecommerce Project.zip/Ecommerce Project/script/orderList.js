 // Sample order data (can be fetched from backend)
 const orders = [
    { id: 1, totalCost: 50, creationDate: "2024-02-20", shipmentDate: "2024-02-25", status: "processing" },
    { id: 2, totalCost: 80, creationDate: "2024-02-18", shipmentDate: "2024-02-23", status: "shipped" },
    { id: 3, totalCost: 30, creationDate: "2024-02-15", shipmentDate: "2024-02-20", status: "delivered" }
  ];

  // Function to populate orders table
  function populateOrdersTable() {
    const tableBody = document.getElementById("orderTableBody");
    tableBody.innerHTML = ""; // Clear previous data
    orders.forEach(order => {
      const row = `
        <tr>
          <td><a href="/views/orderDetail.html" >${order.id}</a></td>
          <td>${order.totalCost}</td>
          <td>${order.creationDate}</td>
          <td>${order.shipmentDate}</td>
          <td>${order.status}</td>
        </tr>
      `;
      tableBody.insertAdjacentHTML("beforeend", row);
    });
  }

  // Initial population of orders table
  populateOrdersTable();

  // Function to sort table by column index
  function sortTable(columnIndex) {
    const table = document.querySelector("table");
    const rows = Array.from(table.querySelectorAll("tr")).slice(1); // Exclude header row
    const isNumeric = !isNaN(Number(rows[0].children[columnIndex].textContent.trim())); // Check if column is numeric

    rows.sort((a, b) => {
      const aVal = isNumeric ? parseFloat(a.children[columnIndex].textContent.trim()) : a.children[columnIndex].textContent.trim();
      const bVal = isNumeric ? parseFloat(b.children[columnIndex].textContent.trim()) : b.children[columnIndex].textContent.trim();
      return aVal > bVal ? 1 : -1;
    });

    // Reverse the order if already sorted
    if (table.querySelector("thead th:nth-child(" + (columnIndex + 1) + ")").classList.contains("sorted")) {
      rows.reverse();
      table.querySelector("thead th:nth-child(" + (columnIndex + 1) + ")").classList.toggle("reversed");
    }

    table.querySelector("thead th.sorted").classList.remove("sorted", "reversed");
    table.querySelector("thead th:nth-child(" + (columnIndex + 1) + ")").classList.add("sorted");

    // Re-append rows to the table
    rows.forEach(row => table.appendChild(row));
  }

  // Function to filter orders by status
  function filterOrders() {
    const status = document.getElementById("statusFilter").value;
    const filteredOrders = status === "all" ? orders : orders.filter(order => order.status === status);
    populateOrdersTable(filteredOrders);
  }

  // Function to view order details
//   function viewOrderDetails(orderId) {
//     // Redirect to order details page or implement details functionality here
//     alert("View Order Details for Order ID: " + orderId);
//   }